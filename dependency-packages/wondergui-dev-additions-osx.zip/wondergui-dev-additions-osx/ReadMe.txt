This zip-file contains files needed to build WonderGUI tools,
examples and addon libraries on Intel Macs.

Just extract the content into your WonderGUI directory and follow the
instructions given elsewhere.


This package contains:

- The FreeType static libarary and header files version 2.10.4. Compiled using
  default settings for optimized build. See freetype.org for more info.