This zip-file contains files needed to build WonderGUI tools,
examples and addon libraries on Intel Macs.




Copy the freetype folder for your architecture to the WonderGUI directory.

Copy the SDL2_image.framework for your architecture to /Library/Frameworks.

You may alternatively install it in <your home directory>/Library/Frameworks if your access privileges are not high enough. (Be aware that the Xcode templates we provide in the SDL Developer Extras package may require some adjustment for your system if you do this.)



This package contains:

- The FreeType static libarary and header files version 2.11.0. Compiled using
  default settings for optimized build. See freetype.org for more info.

- SDL2_Image framework 2.0.5. Compiled using default settings for optimized build.
  See https://www.libsdl.org/projects/SDL_image/ for more info.